var searchData=
[
  ['an_20implementation_20of_20a_20double_20ended_20queue_260',['An implementation of a double ended queue',['../group__DEQUE.html',1,'']]]
];
