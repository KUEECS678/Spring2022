var searchData=
[
  ['sig_225',['sig',['../structKillCommand.html#a20f5367bbec80a936189c57b1f9db351',1,'KillCommand']]],
  ['sig_5fstr_226',['sig_str',['../structKillCommand.html#a879a36b90427ec640bef5c92a6c9c24e',1,'KillCommand']]],
  ['simple_227',['simple',['../unionCommand.html#a269da4d9b16689de14a0ec83636b59e8',1,'Command']]]
];
