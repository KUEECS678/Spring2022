var searchData=
[
  ['type_245',['Type',['../group__DEQUE.html#gac9c83c2070eb6b5891cf742b90f54c68',1,'deque.h']]]
];
